from sqliteshell._sqliteshell import shell

__all__ = [shell]
