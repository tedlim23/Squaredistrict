"""
Package for creating and drawing trees.
"""
__version__ = "v0.2.3"
__author__ = "Pixelwar"
